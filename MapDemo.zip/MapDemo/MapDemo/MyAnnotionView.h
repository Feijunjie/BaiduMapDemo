//
//  MyAnnotionView.h
//  MapDemo
//
//  Created by rhjt on 16/7/22.
//  Copyright © 2016年 junjie. All rights reserved.
//

#import <BaiduMapAPI_Map/BMKMapView.h>

@interface MyAnnotionView : BMKAnnotationView
@property (nonatomic, strong) UIImageView *bgImageView;
@end
