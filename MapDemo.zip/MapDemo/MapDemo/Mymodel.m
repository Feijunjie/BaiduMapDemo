//
//  Mymodel.m
//  MapDemo
//
//  Created by rhjt on 16/7/23.
//  Copyright © 2016年 junjie. All rights reserved.
//

#import "Mymodel.h"

@implementation Mymodel

@end
